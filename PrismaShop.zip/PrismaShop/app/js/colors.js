let colorinput = document.querySelector('#hex');
let color = document.querySelector('#color');

color.addEventListener('input', () =>{
    let cor = color.value;
    colorinput.value = cor;
})

colorinput.addEventListener('input', () =>{
    let cor = colorinput.value;
    color.value = cor;
});

let colorinput2 = document.querySelector('#hex2');
let color2 = document.querySelector('#color2');

color2.addEventListener('input', () =>{
    let cor = color2.value;
    colorinput2.value = cor;
})

colorinput2.addEventListener('input', () =>{
    let cor = colorinput2.value;
    color2.value = cor;
})

let colorinput3 = document.querySelector('#hex3');
let color3 = document.querySelector('#color3');

color3.addEventListener('input', () =>{
    let cor = color3.value;
    colorinput3.value = cor;
})

colorinput3.addEventListener('input', () =>{
    let cor = colorinput3.value;
    color3.value = cor;
})

let colorinput4 = document.querySelector('#hex4');
let color4 = document.querySelector('#color4');

color4.addEventListener('input', () =>{
    let cor = color4.value;
    colorinput4.value = cor;
})

colorinput4.addEventListener('input', () =>{
    let cor = colorinput4.value;
    color4.value = cor;
})